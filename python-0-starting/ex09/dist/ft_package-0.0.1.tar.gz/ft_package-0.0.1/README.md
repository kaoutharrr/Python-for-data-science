# ft_package
A simple educational Python package that counts occurrences in a list.
